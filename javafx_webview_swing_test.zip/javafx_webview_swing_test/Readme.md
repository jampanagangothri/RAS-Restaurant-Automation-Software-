# Description

Example code of running a very simple web browser 
using Web Engine from JavaFX. JavaFX creates the
scene while the scene itself is embedded in a 
Swing Componenent.
