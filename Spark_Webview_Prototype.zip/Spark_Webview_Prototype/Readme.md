# Installation

This is a maven project. The instructions are similar to
spark-chat-test [here](https://github.com/jaylenw/cecs343_prj/tree/master/spark-chat-test).

# Usage

Run the program and a JFrame appears. You can then also open a browser
and enter localhost:4567 to create a new chat instance.
